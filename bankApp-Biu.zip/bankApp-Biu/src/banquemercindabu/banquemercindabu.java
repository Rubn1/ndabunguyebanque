
package banquemercindabu;
import vue.*;

public class banquemercindabu {

    
    public static void main(String[] args) {
         
        Pageauthentification fp = new Pageauthentification();
        fp.setTitle("PAGE DES CONNECTIONS");
        fp.setSize(600, 600);
        fp.setVisible(true);
    }
    
}
