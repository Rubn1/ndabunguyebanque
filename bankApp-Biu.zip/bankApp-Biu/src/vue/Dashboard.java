package vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class Dashboard extends JFrame {
    private JMenuBar menuBar;
    private JMenu menuRecords, menuCategories, menuAccounts, menuReports, menuLogout;

    public Dashboard() {
        initializeFrame();
        createMenuBar();
        createMenuItems();
        setJMenuBar(menuBar);
    }

    private void initializeFrame() {
        setTitle("Banking System Dashboard");
        setSize(1000, 800);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Add a welcome panel
        JPanel welcomePanel = new JPanel();
        welcomePanel.setLayout(new BoxLayout(welcomePanel, BoxLayout.Y_AXIS));
        welcomePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel welcomeLabel = new JLabel("Welcome to the Banking System");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 24));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel instructionLabel = new JLabel("Please select an option from the menu above");
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        instructionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        welcomePanel.add(welcomeLabel);
        welcomePanel.add(Box.createRigidArea(new Dimension(0, 20)));
        welcomePanel.add(instructionLabel);

        add(welcomePanel, BorderLayout.CENTER);
    }

    private void createMenuBar() {
        menuBar = new JMenuBar();
        menuRecords = new JMenu("Records");
        menuCategories = new JMenu("Categories");
        menuAccounts = new JMenu("Accounts");
        menuReports = new JMenu("Reports");
        menuLogout = new JMenu("Logout");

        menuBar.add(menuRecords);
        menuBar.add(menuCategories);
        menuBar.add(menuAccounts);
        menuBar.add(menuReports);
        menuBar.add(menuLogout);
    }

    private void createMenuItems() {
        addMenuItem(menuRecords, "Clients", e -> openForm(new ClientForm(), "Client Management"));
        addMenuItem(menuRecords, "Users", e -> openForm(new FormEmp(), "User Management"));
        addMenuItem(menuRecords, "Agencies", e -> openForm(new CompteForm(), "Agency Management"));

        addMenuItem(menuCategories, "Operation Categories", e -> openForm(new CathegorieForm(), "Operation Categories Management"));

        addMenuItem(menuAccounts, "Accounts", e -> openForm(new CompteForm(), "Account Management"));
        addMenuItem(menuAccounts, "Account Operations", e -> openForm(new OperationForm(), "Account Operations"));

        addMenuItem(menuReports, "Client Accounts", e -> openForm(new Comptes1Client(), "Client Accounts Report"));
        addMenuItem(menuReports, "Accounts and Owners", e -> openForm(new ComptesEtProprio(), "Accounts and Owners Report"));
        addMenuItem(menuReports, "Account Operations", e -> openForm(new OperationSurCompte(), "Account Operations Report"));
        addMenuItem(menuReports, "Agencies and Headquarters", e -> openForm(new OperationSurCompte(), "Agencies and Headquarters Report"));

        addMenuItem(menuLogout, "Logout", e -> logout());
    }

    private void addMenuItem(JMenu menu, String label, ActionListener listener) {
        JMenuItem menuItem = new JMenuItem(label);
        menuItem.addActionListener(listener);
        menu.add(menuItem);
    }

    private void openForm(JFrame form, String title) {
        form.setTitle(title);
        form.setSize(800, 800);
        form.setLocationRelativeTo(this);
        form.setVisible(true);
    }

    private void logout() {
        this.dispose();
        Pageauthentification loginPage = new Pageauthentification();
        loginPage.setTitle("Login Page");
        loginPage.setSize(600, 600);
        loginPage.setLocationRelativeTo(null);
        loginPage.setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new Dashboard().setVisible(true);
        });
    }
}