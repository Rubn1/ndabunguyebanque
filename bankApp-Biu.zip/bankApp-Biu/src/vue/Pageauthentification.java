package vue;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import modele.*;
import controlleur.*;

public class Pageauthentification extends JFrame {
    private JTextField tnom;
    private JPasswordField tpass;
    private JButton bcon, bcreer;
    private JPanel mainPanel, formPanel, buttonPanel;

    public Pageauthentification() {
        setTitle("NDABUNGUYE BANQUE - Authentication");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(400, 300));

        mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        setContentPane(mainPanel);

        // Logo or Bank Name
        JLabel bankName = new JLabel("NDABUNGUYE BANQUE", SwingConstants.CENTER);
        bankName.setFont(new Font("Arial", Font.BOLD, 24));
        mainPanel.add(bankName, BorderLayout.NORTH);

        // Form Panel
        formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridwidth = GridBagConstraints.REMAINDER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        tnom = createStyledTextField("Username");
        tpass = createStyledPasswordField("Password");

        formPanel.add(tnom, gbc);
        formPanel.add(tpass, gbc);

        mainPanel.add(formPanel, BorderLayout.CENTER);

        // Button Panel
        buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        bcon = createStyledButton("Connection");
        bcreer = createStyledButton("Create Account");

        buttonPanel.add(bcon);
        buttonPanel.add(bcreer);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Action Listeners
        bcon.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                authenticateUser();
            }
        });

        bcreer.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                createAccount();
            }
        });

        pack();
        setLocationRelativeTo(null);
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField textField = new JTextField(15);
        textField.setFont(new Font("Arial", Font.PLAIN, 14));
        textField.setBorder(BorderFactory.createCompoundBorder(
            textField.getBorder(), 
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        setPlaceholder(textField, placeholder);
        return textField;
    }

    private JPasswordField createStyledPasswordField(String placeholder) {
        JPasswordField passwordField = new JPasswordField(15);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 14));
        passwordField.setBorder(BorderFactory.createCompoundBorder(
            passwordField.getBorder(), 
            BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        setPlaceholder(passwordField, placeholder);
        return passwordField;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setFocusPainted(false);
        button.setBackground(new Color(0, 123, 255));
        button.setForeground(Color.WHITE);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }

    private void setPlaceholder(JTextField textField, String placeholder) {
        textField.setForeground(Color.GRAY);
        textField.setText(placeholder);
        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                if (textField.getText().equals(placeholder)) {
                    textField.setText("");
                    textField.setForeground(Color.BLACK);
                }
            }

            @Override
            public void focusLost(FocusEvent e) {
                if (textField.getText().isEmpty()) {
                    textField.setForeground(Color.GRAY);
                    textField.setText(placeholder);
                }
            }
        });
    }

    private void authenticateUser() {
        String username = tnom.getText();
        String password = new String(tpass.getPassword());

        boolean trouve = false;
        for (Employe em : Factory.getEmplo()) {
            if (em.getUsername().equals(username) && em.getPassword().equals(password)) {
                Dashboard fp = new Dashboard();
                fp.setTitle("NDABUNGUYE BANQUE");
                fp.setSize(600, 600);
                fp.setVisible(true);
                trouve = true;
                break;
            }
        }

        if (!trouve) {
            JOptionPane.showMessageDialog(this, "Incorrect username or password", "Authentication Failed", JOptionPane.ERROR_MESSAGE);
        }

        effacer();
    }

    private void createAccount() {
    // Open the FormEmp window for account creation
    Acountcrea acountcrea = new Acountcrea();
    acountcrea.setTitle("Create Employee Account");
    acountcrea.setSize(800, 600);  // Set appropriate size for FormEmp
    acountcrea.setVisible(true);  // Show the form
}


    private void effacer() {
        tnom.setText("");
        tpass.setText("");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new Pageauthentification().setVisible(true);
        });
    }
}